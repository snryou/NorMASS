NorMASS
================

This is the code implementing the framework that we describe in our paper 
"NorMASS: An Effective Modeling Framework for Simulating Incentive Mechanisms of Q&A Communities".

The normative MASS-based model described here simulates the reputation mechanism of an online Q&A community. It contains two types of entities,
the users represented by turtles, the posts (including questions and answers) represented by patches. Each of these entities has their own attributes and statistics, such as the number of answers that a user has. 

It cotains six files.

NorMASS.nlogo: the main source code file.
create new users.nls: for creating new agents.
create posts.nls: for simulating post creation.
generate simulation data.nls: for generating simulation users.
norm.nls: simulating the regulation of reputation mechansim
vote posts.nls: for simulating voting posts.

(c) *********, 
    ***************, *****

Requirements
----------------
Requires NetLogo 6.0.4 or higher.

